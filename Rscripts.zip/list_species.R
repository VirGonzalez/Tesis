remotes::install_github("ropensci/rgbif@download-format")

library(rnaturalearth)
library(rgbif)
library(dplyr)
# world map
worldMap <- ne_countries(scale = "medium", type = "countries", returnclass = "sf")
# country subset
CRpoly <- worldMap %>% filter(subregion == 'South America')

user<- "virgonzalez"
pwd<- "Mvg155074037" #my password
email<- "virginiagonzalez782@gmail.com" #my email
res <- occ_download(pred("country", "AR"), type = "within", format = "SPECIES_LIST",type = "within",user=user,pwd=pwd,email=email)
res 
#> <<gbif download>>
#>   Username: sckott
#>   E-mail: myrmecocystus@gmail.com
#>   Format: SPECIES_LIST
#>   Download key: 0000182-190415153152247

occ_download_meta(res) # see when ready

x <- occ_download_get(res) # download
#> Download file size: 4.73 MB
#> On disk at ./0000182-190415153152247.zip

occ_download_import(x) # import into R

spp <- read.csv("C:/Users/musimundo/Documents/Paper Biodiversidad Urbana/" , header = T)

spp <- subset(spp , kingdom == "Plantae" )
spp <- subset(spp , phylum == "Tracheophyta" )
spp <- subset(list , taxonRank == "SPECIES" )
install.packages("openxlsx")
library(openxlsx)
# for writing a data.frame or list of data.frames to an xlsx file
write.xlsx(spp, 'plant_listAR.xlsx')
library(sf)
spp <- st_read("C:/Users/musimundo/Documents/Paper Biodiversidad Urbana/exotica_conosurptos.shp")
getwd()
setwd("C:/Users/musimundo/Documents/Proy.gbif/bases")
fam1 <- spp$family
fam1 <- unique(fam1, na.rm = T)

spp1 <- st_read("C:/Users/musimundo/Documents/Tesis/paper_migraciones/occurrences")
spp1<- spp$species
spp <- unique(spp1)

spp <- setdiff(spp, spp1)

write.xlsx(spp, 'plantlist.xlsx')
