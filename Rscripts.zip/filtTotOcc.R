library(sf)
base <- st_read("C:/Users/musimundo/Documents/Paper Biodiversidad Urbana/exotica_conosurptos.shp")
occ <- st_read("C:/Users/musimundo/Documents/Paper Biodiversidad Urbana/total_oc.shp")
lista <- unique(base$species)
occ <- unique(occ$species)
base1 <- setdiff(occ,lista)
base1<- unique(base1)

newDF <- occ[occ$species %in% base1,]

fam <- unique(newDF$family)
