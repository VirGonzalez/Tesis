library("dplyr")                                    # Load dplyr package
library("plyr")                                     # Load plyr package
library("readr")                                    # Load readr package

getwd() %>% shell.exec()
dirs <- file.path(getwd())
dirs # This is the path were the codes will be stored
dir.create(dirs) # Function for creating the directory where each dataset will be saved

occ_list <- list.files(path = "C:/Users/musimundo/Documents/Proy.gbif/gbif/raw_data2",  # Identify all CSV files
                       pattern = "*.csv", full.names = TRUE) %>% 
  lapply(read_csv) %>%                              # Store all files in list
  rbind.fill()                                        # Combine data sets into one data set 
occ_list                                           # Print data to RStudio console

occ_list$datecollected <- paste(occ_list$year, occ_list$month, occ_list$day, sep = "-")
occ_list$datecollected <- lubridate::ymd(occ_list$datecollected)

# Save this occurrence database as csv
readr::write_csv(occ_list, file.path(dirs, "SPECIESLINK.csv")) # save as csv
