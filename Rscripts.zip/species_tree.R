library(rgbif)
require(scrubr)
library(maps)
# fill in your gbif.org credentials 
user <- "virgonzalez" # your gbif.org username 
pwd <- "Mvg155074037" # your gbif.org password
email <- "virginiagonzalez782@gmail.com" # your email 
library(dplyr)
library(readr)  
library(rgbif) # for occ_download
# The 60,000 tree names file I downloaded from BGCI
file_url <- "https://data-blog.gbif.org/post/2019-07-11-downloading-long-species-lists-on-gbif_files/global_tree_search_trees_1_3.csv"
# match the names 
# Vector with species names
spp <- read.csv("C:/Users/musimundo/Documents/Tesis/paper_migraciones/global_tree_search_trees_1_6.csv")

spp1 <- read.csv("C:/Users/musimundo/Documents/Proy.gbif/gbif/data.csv",              # TXT 
                  header = TRUE, sep = ",")  
str(spp)


spp<- setdiff(spp$TaxonName, spp1$taxon )
spp <- as.data.frame(spp)
gbif_taxon_keys <- 
  spp1 %>%
  #head(1000) %>% # use only first 1000 names for testing
  pull("taxon") %>% # use fewer names if you want to just test 
  name_backbone_checklist()  %>% # match to backbone
  filter(!matchType == "NONE") %>% # get matched names
  filter(kingdom == "Plantae") %>% # remove anything that might have matched to a non-plant
  pull(usageKey) # get the gbif taxonkeys
# gbif_taxon_keys should be a long vector like this c(2977832,2977901,2977966,2977835,2977863)
# !!very important here to use pred_in!!

res <- occ_download(pred("country", "CL"), type = "within", format = "SPECIES_LIST",type = "within",user=user,pwd=pwd,email=email)

spp <- unique(gbif_taxon_keys)
library(sf)
spp1 <- st_read("C:/Users/musimundo/Documents/Paper Biodiversidad Urbana/Analisis/lim1.shp")
limit <- spp1$geometry
new_vector <- unlist(limit, use.names = FALSE)


occ_download(pred("country", "CL"),
  pred("hasCoordinate", TRUE),
  pred("occurrenceStatus","PRESENT"),
  pred_not(
    pred("basisOfRecord", "FOSSIL_SPECIMEN")
  ),
  format = "SIMPLE_CSV",
  user=user,pwd=pwd,email=email
)

occ_download(pred_in("taxonKey", gbif_taxon_keys), pred("country", "CL"),pred("hasCoordinate", TRUE),pred_not(pred("basisOfRecord", "FOSSIL_SPECIMEN")),format = "SIMPLE_CSV",user=user,pwd=pwd,email=email)

occ_download(pred("country", "PE"),
             pred("hasCoordinate", TRUE),
             pred("hasGeospatialIssue", FALSE),
             pred("occurrenceStatus","PRESENT"),
             pred_not(
               pred("basisOfRecord", "FOSSIL_SPECIMEN")
             ),
             format = "SIMPLE_CSV",
             user=user,pwd=pwd,email=email
)

occ_download_wait('0266132-220831081235567')

occ_download_get('0266132-220831081235567') 


%>%
  occ_download_import()

######LISTADO ESPECIES

occ_download(pred_in("country", c("AR", "BO", "CO", "VE","EC", "PE", "BR","PY")),
             format = "SPECIES_LIST",
             user=user,pwd=pwd,email=email
)


#######FILTRAR LISTADO DE ESPECIES

list<- read.csv("C:/Users/musimundo/Documents/Paper Biodiversidad Urbana/0265944-220831081235567/0265944-220831081235567.csv", header = T , sep = "")

spp <- subset(list , kingdom == "Plantae" )
spp <- subset(spp , phylum == "Tracheophyta" )
fam<- unique(spp$taxonKey , na.rm = T)
