library(sf)
bra <- st_read("C:/Users/musimundo/Documents/Proy.gbif/gbif/base_limpia/bra1.shp")
bo<- st_read("C:/Users/musimundo/Documents/Proy.gbif/gbif/base_limpia/bo.shp")
shp <- st_read("C:/Users/musimundo/Documents/Proy.gbif/gbif/base_limpia/sha2.shp")

shp <- rbind(shp,bo)
shp <- rbind(shp,arg)
st_write(shp , dsn = "C:/Users/musimundo/Documents/Proy.gbif/gbif/base_limpia/sha2.shp",layer="sha2", driver="ESRI Shapefile")

spp <- st_read("C:/Users/musimundo/Documents/Proy.gbif/gbif/base_limpia/sha1.shp")
