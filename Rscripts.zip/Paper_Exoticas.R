library(sf)
data <- st_read("C:/Users/pc/Dropbox/PC/Documents/Doctorado/Paper Biodiversidad Urbana/Analisis/GBIF2.shp")

data <- st_read("C:/Users/pc/Dropbox/PC/Documents/Doctorado/Proy.gbif/Analisis/predict.shp")

#escalar
library(dplyr)
data1 = data1 %>%
  mutate_if(is.numeric, scale)
#no escala proporcion
data = data %>%
  mutate_at(vars(one_of( "suma_pob","cultivo_","dens_ganad", "precipitac", "div", "access","temp", "gravedadlo", "road_dens", "fuego", "fundacionm","rich_anim", "N")), scale)

##transformo tipos de ciudades en numeros
data$tipo <- ifelse(data$d1 == 'Metropoli' ,1,
                    ifelse(data$d1 == 'Grandes Ciudades' , 2, 
                           ifelse(data$d1 == 'Ciudad intermedia' ,3,
                                  ifelse( data$d1 == 'Ciudad Peque?a' ,4, 
                                          ifelse(data$d1 == 'Towns' , 5,NA )))))

data$tipo[is.na(data$tipo)]="6"

#limpio la base de datos
length(which(is.na(data$OS)))
data=data[!is.na(data$OS),]

data$intervalom = as.factor(data$intervalom)
data$tipo = as.factor(data$tipo)
length(which(is.na(data$tipo)))
data =data[!is.na(data$N),]

###REMOVER DUPLICADOS
library(tidyverse)
length(which(duplicated(data$id)))
library(dplyr) 
# Remove duplicate rows of the dataframe using NAME variable
data = distinct(data ,ID_1 , .keep_all= TRUE)

###AQUI LE SUMO EL MINIMO A CADA VARIABLE
data$suma_pob = data$suma_pob + min(data$suma_pob, na.rm = TRUE )
data$N = data$N+ min(data$N, na.rm = TRUE )
data$cultivo_ = data$cultivo_ + min(data$cultivo_ , na.rm = TRUE )
data$fundacionm = data$fundacionm + min(data$fundacionm, na.rm = TRUE )
data$temp = data$temp  + min(data$temp , na.rm = TRUE )
data$precipitac = data$precipitac  + min(data$precipitac , na.rm = TRUE )
data$div = data$div  + min(data$div , na.rm = TRUE )
data$dens_ganad = data$dens_ganad  + min(data$dens_ganad , na.rm = TRUE )
data$fuego = data$fuego  + min(data$fuego , na.rm = TRUE )
library(ggplot2)

ggplot(data ,aes(gravedadlo , proporcion )) + 
  geom_point(alpha = 0.2) +
  geom_smooth(method = "loess" , size=0.8, colour = "blue") +
  #scale_y_continuous(limits = c(0,0.5))+
  xlab("Gravity")+ ylab("Alien Species Proportion")+
  theme_bw()+theme(legend.position = "none")

ggplot(data ,aes(tipo, gravedadlo , color = tipo)) + geom_boxplot()+ 
  xlab("Type urbanization")+ ylab("Gravity")+
  theme_bw()+theme(legend.position = "bottom")

m1 = lm(proporcion ~ gravedadlo , data = data)
summary(m1)

library(lme4)
r4 <- glmer(proporcion ~  N + cultivo_  + fundacionm + div + fuego
            +precipitac+ I(precipitac^2)+ temp + I(temp^2) + (1|tipo),
            data = data , family= binomial(link = "logit"), weights= ocurrencia)
summary(r4)
library(sjstats)
r2(r4)



r5 <- glm(proporcion ~  N + cultivo_  + div + fuego+
            precipitac+ I(precipitac^2 )+ temp + I(temp^2) ,data = data , family= binomial(link = "logit"), weights= ocurrencia)

summary(r5)

#Ploteo para ver residuos cuando saco los tipos de ciudades
library(broom)
resid <- tidy((residuals(r5,"pearson", scaled = TRUE)))

library(ggplot2)
names(data)
data$tipo <- factor(data$tipo , levels=c("1", "2", "3", "4", "5", "6"))
data$OS = as.factor(data$OS)
ggplot(data ,aes( OS , fundacionm, color = OS)) + 
  geom_boxplot()+
  #guides(col= guide_legend(title= "Foundation date"))+
  #scale_x_continuous(limits = c(0,3))+
  xlab("Ornamental Species")+ ylab("Foundation Date")+
  theme_bw() +theme(legend.position = "bottom")
names(data)

ggplot(data ,aes( fundacionm , OS )) + 
  facet_grid(~factor(tipo ))+
  geom_point(alpha = 0.2) +
  geom_smooth(method = "loess" , size=0.8, colour = "black") +
  #scale_x_continuous(limits = c(0,3))+
  ylab("Foundation date")+ xlab("Ornamental Species")+
  theme_bw()+theme(legend.position = "none")

library(sjPlot)
library(sjmisc)
library(sjlabelled)
library(ggplot2)
sjPlot::plot_model(r4,type = "est", 
                   axis.labels=c("Temperature","Temperature","Precipitation", "Precipitation","Fire freq.", "Land use Diversity" ,"Foundation date", "Crop percentage","Native plants richness" ),vline.color = "grey",
                   show.values=TRUE, value.offset = .5, show.p=TRUE)
tab_model(m1, show.intercept = TRUE,
          show.est = TRUE, digits = 5, p.style = "scientific_stars", 
          dv.labels = c("Alien species Proportion") ,  pred.labels = c("Intercept", "Gravity")
          )

##mapping predicts
###MAPEO PREDICTS
library(ggplot2)
library(ggspatial)
library(ggthemes)
library(RColorBrewer)
display.brewer.all()
my.palette <- brewer.pal(n = 5, name = "RdYlGn")
data$pred <- predict(r4 , newdata =data , type = "response", allow.new.levels = TRUE )
ggplot(data = data )  +geom_sf(aes(fill= pred ), color = NA) +xlab("Long") + ylab("Lat")+ scale_fill_gradientn(name= "Predicts", 
                                                                                                               colours= my.palette, na.value="grey" )+
  annotation_scale()  +
  annotation_north_arrow(location='tr')+theme_classic()+
  theme_classic()+theme(axis.title.x = element_text(face="bold", vjust=-1, size=rel(1))) +
  theme(axis.title.y = element_text(face="bold", vjust=1, size=rel(1.))) 

st_write(data , dsn = "C:/Users/pc/Dropbox/PC/Documents/Doctorado/Paper Biodiversidad Urbana/Analisis/predict.shp",layer="predict", driver="ESRI Shapefile")
library(sf)
data <- st_read("C:/Users/pc/Dropbox/PC/Documents/Doctorado/Paper Biodiversidad Urbana/exotica_conosurptos.shp")
names(data)
m = list(levels(as.factor(data$countryCod)))
m = data.frame(m)
m
library(dplyr)
m %>% select_if(~ is.factor(data$countryCod) && any(c("UY") %in% levels(.)))
length(which(data$countryCod == "BR"))
library("writexl") 
write_xlsx(m ,"Paper Biodiversidad Urbana/Analisis/df.xlsx")
