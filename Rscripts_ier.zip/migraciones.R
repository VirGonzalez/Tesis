library(sf)
base <- st_read("C:/Users/Usuario/Mi unidad/Proy.gbif/Arboles_exoticos/paises1.shp")
puntos<- st_read("G:/Mi unidad/Arboles_exoticos/data_e.shp")

names(base)

length(unique(puntos$accepted_1))
p1 = subset(puntos, country_su == "Colombia")

######## <UNIR POBLACION> ###############

POB <- read.csv("D:/Tesis/paper_migraciones/mig (2)/pob.csv", header = T, sep = ";")
merge <- merge(base, POB, by.X = c("NAME_0", "PAIS"), by.y = c("NAME_1", "DEP"))



base$inming = base$inmig_m1 + base$inming_f1

base$emig = base$emig_f1 + base$emig_m1 

base$net = base$inming - base$emig

base$migxpob = base$net/base$tp

library(dplyr)
base = base %>%
  mutate_if(is.numeric, scale)

st_write(base , dsn = "C:/Users/Usuario/Documents/Tesis/paper_migraciones/mig (2)/mig/migraciones.shp",layer="migraciones", driver="ESRI Shapefile" )
library(dplyr)
base$inmig <- as.numeric(base$inmig)
base$emig <- as.numeric(base$emig)
names(base)

base <- base %>%
  mutate_at(vars(one_of( "ntl_hab", "ntl_dif", "imn_p", "agemean","tempmean", "precipanua", "ntltrendme", "net" , "TP", "inmig" )), scale)
library(ggplot2)
ggplot(base ,aes(sp_ex , net)) + 
  geom_point(alpha = 0.5) +
  geom_smooth(method = "lm",se=T, fullrange=TRUE, size = 1, aes(color = "pink" )) +
  #facet_wrap(~factor(NAME_0 ))+
  #scale_x_continuous(limits = c(0,0.5))+
  #xlab("Exotic trees proportion")+ ylab("Immigrant per habitant")+
  guides(colour=guide_legend(override.aes=list(alpha=1, size=3)))+
  theme_bw()+theme(legend.position = "bottom")+
  theme(axis.title.x = element_text(face="bold", vjust=-1.5, size=rel(1))) +
  theme(axis.title.y = element_text(face="bold", vjust=1.5, size=rel(1))) 

ggplot(data ,aes(net , radsum )) + 
  geom_point(alpha = 0.5) +
  geom_smooth(method = "loess",se=TRUE, fullrange=TRUE, size = 1, aes(color = "#E78AC3")) +
  #scale_y_continuous(limits = c(0,3))+
  xlab("Net migrations")+ ylab("NTL sum")+
  guides(colour=guide_legend(override.aes=list(alpha=1, size=3)))+
  theme_bw()+theme(legend.position = "none")+
  theme(axis.title.x = element_text(face="bold", vjust=-1.5, size=rel(1))) +
  theme(axis.title.y = element_text(face="bold", vjust=1.5, size=rel(1))) 

######corplot##########

# install.packages("psych")
library(psych)

df = as.data.frame(base)
corPlot(df[,20:38],stars = TRUE, upper = FALSE)





#####BOXPLOT########

plot <- ggplot(base ,aes(NAME_0 , nativas  , color = NAME_0 )) + 
  geom_boxplot()+
 #scale_y_continuous(limits = c(0,20000))+
  xlab("Country")+ ylab("Native trees abundance")+
  guides(colour=guide_legend(override.aes=list(alpha=1, size=3)))+
  theme_bw()+theme(legend.position = "none")+
  theme(axis.title.x = element_text(face="bold", vjust=-1.5, size=rel(1))) +
  theme(axis.title.y = element_text(face="bold", vjust=1.5, size=rel(1)))

plot(plot)

########### Grafico de dispersion #########

library(ggplot2)
library(dplyr)
library(hrbrthemes)
library(viridis)

base$net_p = base$imn.p - (base$emig/base$TP)

ggplot(base , aes(x = xcoord , y = ycoord)) +
  geom_point(aes(color = NAME_0 , size = TP), alpha = 0.5) +scale_fill_viridis(discrete=TRUE, guide=FALSE, option="A")+ 
  scale_size_area(name = "Exotic Trees Proportion", max_size = 10) +
  theme_ipsum() +
  theme(legend.position="right")



######### MAPA #############
library(ggplot2)
library(ggspatial)
library(ggthemes)
library(RColorBrewer)
display.brewer.all()
my.palette <- brewer.pal(n = 5, name = "RdYlGn")

ggplot(data = base )  +geom_sf(aes(fill= nat_ex ), color = NA) +xlab("Long") + ylab("Lat")+ scale_fill_gradientn(name= "Native tree richness", 
                                                                                                               colours= my.palette, na.value="grey" )+
  annotation_scale()  +
  annotation_north_arrow(location='tr')+theme_classic()+
  theme_classic()+theme(axis.title.x = element_text(face="bold", vjust=-1, size=rel(1))) +
  theme(axis.title.y = element_text(face="bold", vjust=1, size=rel(1.))) 

library(psych)

corPlot(base[,20:38])


#Fit a linear model by robust regression using an M estimator.
#
base$ntl_hab = base$ntl_count/base$TP
#
m1 = lm(proporcion ~ agemean + tempmean + precipanua + ntl_hab + ntltrend, base)  #####MEJOR MODELO 
summary(m1)

m2 = lm(sp_ex ~  agemean + precipanua + imn_p , base ) ####me gusta

m2 = lm(sp_ex ~  agemean + precipanua + net, base ) ####me gusta

summary(m2)
step(m2)



m3 = lm(proporcion ~ inming + radsum , data)
summary(m1)
m4 = lm(proporcion ~ net + rad.km2 , data)
summary(m4)

step(m1)


#########    Modelos mixtos      ##########
names(base)
library(lme4)
r4 <- glmer(proporcion ~  imn.p  + agemean + tempmean  + conflict + (1|NAME_1), data = base , family= binomial(link = "logit"))

r5 <- glmer(proporcion ~  net  + agemean + tempmean  + conflict + (1|NAME_1), data = base , family= binomial(link = "logit"))

summary(r4)

summary(r5)

r4 <- glmer(sp_ex ~  imn.p + ntl_hab  + agemean + tempmean + precipanua + nat_ex + (1|NAME_0),
            data = base )






######### Hago un raster que sea un mapa de calor#########
######### 


library(MASS)

library(raster)
base = st_read("D:/Tesis/paper_migraciones/mig (2)/mig/puntos.shp")

base_f <- st_transform(base, crs = 22183)
library(spatstat)
W <- as.owin(base_f$geometry[1]) # First county of North Carolina data set in spatstat format
X <- runifpoint(100, win = W)
plot(X, "Random points")

library(ggplot2)

ggplot(data = base) +
  geom_sf() +
  theme_bw() +
  stat_density_2d(mapping = ggplot2::aes(x = purrr::map_dbl(geometry, ~.[1]),
                                         y = purrr::map_dbl(geometry, ~.[2]),
                                         fill = stat(density)),
                  geom = 'tile',
                  contour = FALSE,
                  alpha = 0.5)



#####CURVA ESPECIE ABUNDANCIA#################


sp_occ <-st_read("D:/Proy.gbif/gbif/Arboles_exoticos/data_e.shp")

length(unique(puntos$accepted_1))
a = length(sp_occ$database_i)

p1 = subset(sp_occ, country_su == "Colombia")

b = length(p1$database_i)
c = b/a*100

ibrary(dplyr)

library(tidyr)

df2 <- sp_occ %>% 
  group_by(country_su) %>% 
  count(accepted_1) 


abundance <- dplyr::count(sp_occ , accepted_1)            # Applying count function

library(data.table)
fwrite(df2, "abundancia_exoticas.csv")


library(vegan)
###abundance <- as.data.frame(t(abundance))
library("tidyverse")  

abundance <- df2[,2:3] 
nombres <- names(abundance)[-c(1,1)]

# Fit species accumulation curve
library(vegan)
# Create a matrix we can use with vegan

# Load the packages
library(vegan)
library(picante)
library(knitr)
 df2= df2  %>% select("country_su", "n", "accepted_1")

ec.matrix <- sample2matrix(df2)
curve <- specaccum(ec.matrix, method = "random", permutations = 1000)
curve


plot(curve, ci.type = "poly", col = "blue", ci.col = "lightblue", 
     lwd = 2, ci.lty = 0, xlab = "Paises", 
     ylab = "cumulative number of exotic tree species")

# Plot
# 
curve.df <- data.frame(sites = curve$sites,
                               richness = curve$richness,
                               sd = curve$sd)


ggplot(df2 , aes(x = accepted_1 , y = n , colour = country_su )) +
  # Add line
  geom_point() +
  geom_smooth(method = "lm")+
  # Add confidence interval+
  # Remove grey background
  theme_bw(base_size = 14)



RpA<- radfit(df2[,])
RpA

plot(RpA$models$Mandelbrot , xlim=c(0,250), pch=19, col="pink", cex=0.6)

###Calculo indice de diversidad
diversity(abundance, "simpson")

library(metacoder)
abundancia <- parse_tax_data(abundancia_exoticas , class_sep = ";", class_cols = "accepted_1")

abundancia %>%
  metacoder::filter_taxa(n > 0) %>% # metacoder:: needed because of phyloseq::filter_taxa
  heat_tree(node_label = accepted_1,
            node_size = n, 
            node_color = n, 
            layout = "da", initial_layout = "re", 
            title = "Taxa in leafs")


######3plot heatmap
######

