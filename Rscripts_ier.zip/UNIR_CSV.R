library("dplyr")                                    # Load dplyr package
library("plyr")                                     # Load plyr package
library("readr") 

dirs <- file.path(getwd(), "raw_data")
dirs # This is the path were the codes will be stored
dir.create(dirs) # Function for creating the directory where each dataset will be saved
data_all <- list.files(path = "D:/Proy.gbif/gbif/raw_data",  # Identify all CSV files
                       pattern = "*.csv", full.names = TRUE) %>% 
  lapply(read_csv) %>%                              # Store all files in list
  rbind.fill() 



data_all 
# Print data to RStudio console
library(data.table)
write_xlsx(data_all , "D:/Proy.gbif/gbif/BIEN.csv")

fwrite(data_all, "D:/Proy.gbif/gbif/intermedio_n/intermedio/IDIGBIO.csv")


readr::write_csv(data_all , file.path(dirs, "BIEN.csv"))



sl1 = read.csv("D:/Proy.gbif/gbif/Arboles_exoticos/00_merged_database.csv")
sl2 = read.csv("D:/Proy.gbif/gbif/Output/Intermediate/00_merged_database.csv")
base = rbind.fill(sl1 , sl2)
